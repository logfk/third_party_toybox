#!/bin/bash
# run-board.sh - 在 Windows (Git Bash/MSYS2/WSL) 上通过 hdc 推送并执行测试
# 使用 build-bundle.sh 预编译的 ARM 二进制
#
# 前置条件: hdc 已配置并连接到主板
# 用法:     ./run-board.sh [test_name...]
# 首次需配置 HDC:  export HDC=/path/to/hdc.exe

TOP="$(cd "$(dirname "$0")" && pwd)"
BIN_DIR="$TOP/bin"
TEST_OH_DIR="$TOP/test-oh"
SCRIPT_DIR="$TOP/scripts"
BOARD_DIR=/data/toybox-test

# hdc 路径 - 用户需根据实际位置设置
HDC="${HDC:-hdc}"

echo "===== 板端测试运行器 ====="
echo "  HDC:       $HDC"
echo "  BOARD_DIR: $BOARD_DIR"
echo "  测试数:    $# 个"

# 检查主板连接
"$HDC" list targets 2>&1 | grep -q "." || {
  echo "错误: 未检测到主板 (hdc list targets 为空)"
  echo "请确认: 1) USB 已连接  2) hdc 路径正确  3) hdc start 已运行"
  exit 1
}

echo "===== 清理主板旧文件 ====="
"$HDC" shell "rm -rf $BOARD_DIR && mkdir -p $BOARD_DIR"

# 推送全部预编译二进制
echo "===== 推送二进制到主板 ====="
BIN_COUNT=0
for f in "$BIN_DIR"/*; do
  [ -f "$f" ] || continue
  CMDNAME="$(basename "$f")"
  echo "  [推送] $CMDNAME"
  "$HDC" file send "$f" "$BOARD_DIR/$CMDNAME" >/dev/null 2>&1
  "$HDC" shell "chmod +x $BOARD_DIR/$CMDNAME"
  ((BIN_COUNT++))
done
echo "  共推送 $BIN_COUNT 个命令"

# 准备测试环境变量
export TOPDIR="$TOP"
export OHOS_TEST=1
export SHOWSKIP=SKIP
export FAILCOUNT=0

# 加载测试框架
source "$SCRIPT_DIR/runtest.sh"

# OPTIONFLAGS
[ -f "$SCRIPT_DIR/config.h" ] &&
  export OPTIONFLAGS=:$(sed -n 's/^#define CFG_\(.*\) 1$/\1/p' "$SCRIPT_DIR/config.h" | tr '\n' :)

# 如果无参数，跑全部
[ $# -eq 0 ] && set -- "$TEST_OH_DIR"/*.test

# ====== 重写 testing()：通过 hdc 在板端执行命令 ======
testing() {
  wrong_args "$@"
  [ -z "$1" ] && NAME="$2" || NAME="$1"
  [ "${NAME#$CMDNAME }" == "$NAME" ] && NAME="$CMDNAME $1"
  [ -n "$DEBUG" ] && set -x

  if [ "$SKIP" -gt 0 ]; then
    verbose_has quiet || printf "%s\n" "$SHOWSKIP: $NAME"
    ((--SKIP)); return 0
  fi

  local TESTDIR="$TOPDIR/_test/${CMDNAME}_$$"
  mkdir -p "$TESTDIR/testdir"
  cd "$TESTDIR/testdir" || return 1

  # 写入期望结果
  echo -ne "$3" > "$TESTDIR/expected"

  # 写入 input 文件
  [ -n "$4" ] && echo -ne "$4" > input

  # 同步本地文件到板端
  for f in * .*; do
    [ "$f" = "." ] || [ "$f" = ".." ] && continue
    [ -f "$f" ] && "$HDC" file send "$f" "$BOARD_DIR/$f" >/dev/null 2>&1
  done

  # 推送 stdin
  if [ -n "$5" ]; then
    printf '%s' "$5" | "$HDC" shell "cat > $BOARD_DIR/stdin" 2>/dev/null
  fi

  # 构建远程命令：将 $C 替换为板端路径
  REMOTE_CMD="$2"
  REMOTE_CMD="${REMOTE_CMD//\$C/$BOARD_DIR/$CMDNAME}"

  # 在板端执行
  if [ -n "$5" ]; then
    ACTUAL=$("$HDC" shell "cd $BOARD_DIR && $REMOTE_CMD < stdin" 2>/dev/null)
  else
    ACTUAL=$("$HDC" shell "cd $BOARD_DIR && $REMOTE_CMD" 2>/dev/null)
  fi
  RETVAL=$?

  echo -ne "$ACTUAL" > "$TESTDIR/actual"
  [ $RETVAL -gt 128 ] && echo "exited with signal (or returned $RETVAL)" >> "$TESTDIR/actual"

  # 比对
  DIFF="$(cd "$TESTDIR"; diff -au expected actual 2>&1)"
  [ -z "$DIFF" ] && do_pass || { VERBOSE=all do_fail; }

  if ! verbose_has quiet && { [ -n "$DIFF" ] || verbose_has spam; }; then
    [ -n "$4" ] && printf "%s\n" "echo -ne \"$4\" > input"
    printf "%s\n" "echo -ne '$5' | $REMOTE_CMD"
    [ -n "$DIFF" ] && printf "%s\n" "$DIFF"
  fi

  [ -n "$DIFF" ] && ! verbose_has all && { cd "$TOP"; return 1; }
  rm -f input "$TESTDIR/../expected" "$TESTDIR/../actual"
  rm -rf "$TESTDIR"
  [ -n "$DEBUG" ] && set +x
  return 0
}

# ====== 遍历执行测试 ======
for testfile in "$@"; do
  CMDNAME="$(basename "${testfile%.test}")"
  BOARD_CMD="$BOARD_DIR/$CMDNAME"
  echo ""
  echo "=========================================="
  echo "  测试: $CMDNAME"
  echo "=========================================="

  # 检查二进制是否存在
  "$HDC" shell "[ -f $BOARD_DIR/$CMDNAME ]" 2>/dev/null || {
    echo "  [跳过] 二进制 $CMDNAME 不在板端"
    continue
  }

  # 在顶层 TOP 目录下加载 .test
  C="$BOARD_DIR/$CMDNAME"
  (
    cd "$TOP"
    source "$TEST_OH_DIR/$CMDNAME.test"
    echo "$FAILCOUNT" > "$TOP/_test/${CMDNAME}_continue"
  ) || true

  if [ -f "$TOP/_test/${CMDNAME}_continue" ]; then
    FAILCOUNT=$(($(cat "$TOP/_test/${CMDNAME}_continue") + FAILCOUNT))
    rm -f "$TOP/_test/${CMDNAME}_continue"
  fi

  # 清理板端
  "$HDC" shell "rm -rf $BOARD_DIR/*" 2>/dev/null
done

# 恢复二进制（清理时删掉了所有，重新推送一次以便后续测试）
for f in "$BIN_DIR"/*; do
  [ -f "$f" ] || continue
  "$HDC" file send "$f" "$BOARD_DIR/$(basename "$f")" >/dev/null 2>&1
  "$HDC" shell "chmod +x $BOARD_DIR/$(basename "$f")" 2>/dev/null
done

echo ""
echo "=========================================="
[ $FAILCOUNT -eq 0 ] && echo "  全部通过!" || echo "  失败: $FAILCOUNT"
echo "=========================================="
exit $FAILCOUNT
